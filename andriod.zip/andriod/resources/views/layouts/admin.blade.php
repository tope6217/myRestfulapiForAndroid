<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>
    <link rel="stylesheet" href="{{ asset('src/metisMenu.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/mm-vertical.css') }}">
    <!-- Scripts -->
    <script src="{{ asset('js/jquery.js') }}"></script>
    <script src="{{ asset('assets/js/mm-vertical.js') }}"></script>
    <script src="{{ asset('assets/js/metismenu.js') }}"></script>

    <script src="{{ asset('src/index.js') }}"></script>


    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <script src="{{ asset('bootstrap/js/bootstrap.js') }}"></script>

    <!-- Styles -->
    <link href="{{ asset('bootstrap/css/bootstrap.css') }}" rel="stylesheet">
    <script src="{{ asset('js/loading.js') }}"></script>

    <style>
        body{


        }
    .displays{
        display: none;
    }
    tr td{
      font-size: 10px;
    }
    tr td span{
      font-size: 10px;
    }
        .sidebar-nav{
            position: absolute;
            left:0;
            width:300px;
            /*height:100px; */
        }
        .left-bar ul{
            padding: 0;
            margin:5px;
        }

        .left-bar ul li{
            padding: 0;
            margin:0;
            text-decoration: none;
            width: 100%;
        }
        .left-bar ul li a{
            text-transform: capitalize;
            text-decoration: black;
            color: black;
            width: 100%;
            padding: 10px;
            padding-top: 3px;
            padding-bottom: 3px;
        }
        .left-bar ul li a:hover{
            background-color: white;
            transition: .1s;
            border-radius: 3%;
        }

        .content{
            margin-left:21em;
        }

        .loading{
            position: absolute;
            height: 100%;
            width: 100%;
        }
        .loading .img{
            position: inherit;
            top:40%;
            left:40%
        }
        @media screen and (max-width: 1000px) {
            .sidebar-nav{
                top:0; 
                width:100%;
                position: relative;
            }
            .content{
                margin-left:0;
            }
        }

    </style>
</head>
<body>
<script src="{{asset('js/action.js')}}"></script>
    <div class="left-bar">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    {{ config('app.name', 'Laravel') }}
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" >
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->


                    </ul>
                </div>
            </div>
        </nav>
        <div class="p-2">
            <p class="msg alert-info text-center mt-3  text-capitalize"></p>
       </div>
       <nav class="sidebar-nav collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="metismenu" id="menu1" aria-expanded="false">
            <li>
              <a class="has-arrow" href="#">
                <span class="fa fa-fw fa-github fa-lg"></span>
                Dashboard
              </a>
              <ul>
                <li>
                    <a class="nav-link text-capitalize" name="intro" href="{{route('network.index')}}">update network</a>
                </li>
                <li>
                <a class="nav-link text-capitalize" href="{{route('data.index')}}"><span class="fa fa-fw fa-code-fork"></span>buy data</a>
                </li>

                <li>
                <a class="nav-link text-capitalize"  href="{{route('electricity.index')}}">buy electricity</a>
                </li>
                <li>
                <a class="nav-link text-capitalize" name="intro"  href="{{route('internet.index')}}">Update internet</a>
                </li>

                <li>
                <a class="nav-link text-capitalize" name="intro" href="{{route('airtime.index')}}">Airtime</a>
                </li>
                <li>
                    <a class="nav-link text-capitalize" name="intro" href="{{route('cable.index')}}">Update cable</a>
                    </li>

                    <li>
                    <a class="nav-link text-capitalize" name="intro" href="{{route('cableTv.index')}}">cableTv</a>
                    </li>
                    <li>
                    <a class="nav-link text-capitalize" name="intro" href="{{route('internetdata.index')}}">smile and spectranet data</a>
                    </li>
                    <li>
                    <a class="nav-link text-capitalize" name="intro" href="{{route('internetairtime.index')}}">smile and spectranet Recharge</a>
                    </li>

              </ul>
            </li>

            <li>
              <a class="has-arrow" href="#" aria-expanded="true" >Transaction</a>
              <ul>
                <li>
                    <a class="nav-link text-capitalize" name="intro" href="{{route('debit')}}">All Debit Transaction </a>
                </li>
                <li>
                    <a class="nav-link text-capitalize" name="intro" href="{{route('credit')}}">All Credit Transaction</a> 
                </li>
                <li>
                    <a class="nav-link text-capitalize" name="intro" href="{{route('todayDebit')}}">Today debit Transaction</a>
                </li>

                <li>
                    <a class="nav-link text-capitalize" name="intro" href="{{route('todayCredit')}}">Today Credit Transaction</a>
                </li>
                <li>
                    <a class="nav-link text-capitalize" name="intro" href="{{route('refunded')}}">refunded Transaction</a>
                </li>

                <li>
                    <a class="nav-link text-capitalize" name="intro" href="{{route('unsettled')}}">unsettled Transaction</a>
                </li>
              </ul>
            </li>

            <li>
                <a class="has-arrow" href="#" aria-expanded="true" >message</a>
                <ul>
                  <li>
                    <a class="nav-link text-capitalize" name="api" href="{{route('message')}}">message</a>
                </li>
                </ul>
              </li>

            <li>
                <a class="has-arrow" href="#" aria-expanded="true">api</a>
                <ul>
                  <li>
                    <a class="nav-link text-capitalize" name="api" href="{{route('api')}}">api setup</a>
                </li>
                </ul>
              </li>
              <a href="{{route('users')}}"  >users</a>
              <a href="{{route('logout')}}"  >logout</a>
          </ul>
        </nav>
    <div class="loading load d-none" style="">
        <div class="img">
                <img src="{{asset('image/loading.gif') }}" height="130px" alt="" srcset="">
        </div>
    </div>
    <main class="content">
        @if(count($errors) >0)
        <div class="alert-danger text-center">
            @foreach($errors->all() as $error)
                <span class="d-block">{{$error}}</span>
            @endforeach
        </div>
        @endif
        @if(session()->get('success'))
        <div class="alert-success text-center">
            <span>{{session()->get('msg')}}</span>
        </div>
        @endif
        <div class="msg"></div>
        @yield('content')
    </main>
</div>

    <script src="{{ asset('js/action.js') }}"></script>
    <script>
        $(function() {
        $('#menu1').metisMenu({
        toggle: true
        });
 

        });
        w = ($(window).width())

        function page(){
            if(w > 999){
                $('.sidebar-nav').removeClass('collapse')
            }else{
                $('.sidebar-nav').addClass('collapse')

            }
        }
        page()

        $(window).resize(function(){
            w = ($(this).width())
            page()
        })
    </script>
</body>
</html>
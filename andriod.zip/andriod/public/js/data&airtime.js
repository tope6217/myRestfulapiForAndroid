d={
    type:'',
    status:''
}


$('#dtype').change(function(){

    d.type=$(this).val();
    //console.log(d.type)
    $('#damount').empty()
    for(i=0;i<data.length;i++){
        if(data[i].network_name==d.type){
            console.log(data[i].amount)
           $('#damount').append($('<option/>').val(data[i].id).text(data[i].amount+' '+data[i].description))
        }
    }
})


$('#damount').change(function(){
dd=$(this).val();
console.log(data)

for(i=0;i<data.length;i++){
    if(data[i].id==dd){
        console.log(data[i].price)
       $('#dprice').val(data[i].price)
    }
}
})

$('#aamount').blur(function(){
   type= $('#aNetwork').val();
   amount=parseInt($('#aamount').val());
   console.log(type)
   for(i=0;i<airtime.length;i++){
       if(airtime[i].id == type){
           $('#aprice').val(parseInt(amount*(parseInt(airtime[i].percentage)/100)))
       }
   }
   
})

function loaded(){
    $('.load').removeClass('d-none')
    $('html').css('opacity',0.5)
}

function loading(){
    $('.load').addClass('d-none')
    $('html').css('opacity',1)
}
document.addEventListener('readystatechange', () => loading());
document.addEventListener('DOMContentLoaded', () => loaded()); 

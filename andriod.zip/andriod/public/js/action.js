function  Delete(event){
    loaded()
    event.target
    $(event.target).hide();
    $(event.target).parent().find('.update').removeClass('displays')
    var tds=$(event.target).parent().parent().find('td');
var idd=$(tds[0]).text()
url=$(tds).parent().parent().parent().parent().find('#t_url').val()

$.ajax({
        url:url,
        data:'id='+idd,
        type:'GET',
        beforeSend : function(){
            loaded()
        },
        success : function(result){
            console.log(result)
            if(result.status==true){
                $(tds).parent().empty();
            }
            $('.msg').text(result.msg)
            
        },    
        error : function()    {
            
        },
    }).always(function(){
        loading()
    })
}

 function show(event){
    console.log(event)
    $.ajax({
        url:event,
        type:"Get",
        beforeSend : function(){
            loaded()
        },
        success : function(result){
            if(result.success == true){
               show = $('#show')
               $(show).find('form').attr('action',event)
               $.each(result.data[0],function(id,val){
                   $(show).find('[name='+id+']').val(val)
               })
               $('#show').modal('show')
            }
            console.log(result)
        },
        
    }).always(function(err){
        console.log(err)
        loading()
    })
    
}


function Update(event) {
    loaded()
    th = event.target;
    tarr1=[];
    tarr=[];
    var up=$(th)
    $(th).parent().find('.edit').show()
    tarr1[0]='id';
    var utds=$(th).parent().parent().find('td');
    var id=$($(utds)[0]).text()
    var uths=$(th).parent().parent().parent().parent().find('th')
   // console.log(uths)
    tarr.push(id)
    for(i=1;i<utds.length-1;i++){
        var text=$($(utds[i])).find('input').val();
        var text2=$($(uths[i])).text()
        $(utds[i]).empty()
        tarr.push(text)
        tarr1.push(text2)
        $(utds[i]).text(text)
    }
  var  u_data='';
for(i=0;i<tarr.length;i++){
    u_data=u_data+tarr1[i]+'='+tarr[i]+'&'
}
url=''
url=$(uths).parent().parent().parent().parent().find('#t_url').val()
$.ajax({
        url:url,
        data:u_data+'_token='+$('[name=csrf-token]').attr('content'),
        type:'POST',
        beforeSend : function(){
            loaded()
        },
        success : function(result){
            console.log(result)
            $(up).addClass('displays');
            if(result.status==true){
                
            }else{
            
            }
            $('.msg').text(result.msg)

            
        },    
        error : function(err)    {
            alert('network issue');
            $('.m-success').empty().text('error reloading the page...')  
            $('.msg').text(err.responseJSON.message)  
        },

    }).always(function(){

        loading()
    })
}


function Edit(event) {
    loaded()
    console.log(event.target)
$(event.target).hide();
    $(event.target).parent().find('.update').removeClass('displays')
    var tds=$(event.target).parent().parent().find('td');
    var id=$($(tds)[0]).text()
    for(i=1;i<tds.length-1;i++){
        var text=$(tds[i]).text();
        $(tds[i]).empty()
        $(tds[i]).append($('<input/>').val(text))
    }
    loading()
}



  $('.form').submit(function(e){
    e.preventDefault()
    console.log(this)
    form = this
    dat=$(this).parent();
    //type=(dat.find('[name=type]')).val().toLowerCase()
    //dat.find('#submit').attr('disabled','')
    //console.log(dat.serialize())
    //console.log(aja('serviceCode=V-Internet&type=SMILE&account=1402000567'))
    $.ajax({
        url:$(form).attr('action'),
        data:$(form).serialize(),
        type:$(form).attr('method'),
        beforeSend : function(){
            $('.modal').modal('hide')
            console.log($(this).attr('action'))

            loaded();
        },
        success : function(result){
            console.log(result)
            if($(form).attr('permission') == 'no'){
                $('.msg').text(result)
                
                totop()
                loading()
                return 0;
            }
         // console.log($(form).attr('id'))
            //result=JSON.parse(result)
            switch ($(form).attr('id')) {
                case 'search':
                    $('.loading-table tbody').empty()
                    credits= result.credit
                    debits = result.debit

                    t=`<tr>
                    <td scope="col" id='category'></td>
                    <td scope="col" id="created_at"></td>
                    <td scope="col" id='product_name'></td>
                    <td scope="col" id="destination"></td>
                    <td scope="col" id=quantity></td>
                    <td scope="col" id='charges'></td>
                    <td scope="col" id="price"></td>
                    <td scope="col" id="debited_price"></td>
                    <td scope="col" id="reference"></td>
                    
                    <td scope="col" id='amount'></td>
                    </tr>`
                    c=  `        <tr>
                    <td scope="col" id='id'></td>
                    <td scope="col" id="email"></td>
                    <td scope="col" class='reference' id="reference"></td>
                    <td scope="col" id="amount"></td>
                    <td scope="col" id="created_at"></td>
                    <td scope="col" ><span class="btn-primary btn" onclick="checkTransaction(event)" ><i class="far fa-edit"></i>check</span></td>
                  </tr>`
                    table(t,debits,$('table')[0])
                    table(c,credits,$('table')[1])


                    break;
                case 'update':
                    $('tbody').empty()
                    // $.each(result, function(id,state){
                    //     $('tbody').append(`<tr><td class="text-capitalize">${state.id}</td><<td class="text-capitalize">${state.network_name}</td><td class="text-capitalize">${state.amount}</td><td class="text-capitalize">${state.price}</td><<td class="text-capitalize">${state.plan_code}</td><td class="text-capitalize">${state.check_balance}</td><td class="text-capitalize">${state.description}</td>                    <td class="text-capitalize"><span class="btn-primary btn displays update" onclick="Update(this)" id="update"><i class="far fa-edit"></i>Update</span><span class="btn-primary btn edit" onclick="Edit(this)" id="update"><i class="far fa-edit"></i>Edit</span><span onclick="Delete(this)" class="btn-danger delete btn"  id="delete"><i class="fas fa-trash-alt"></i>delete</span></td></tr>`)
                    // })
                    //`<tr><td class="text-capitalize" id='id'></td><<td id='network_name' class="text-capitalize"></td><td class="text-capitalize" id='amount'></td><td id='price' class="text-capitalize"></td><<td id='plan_code' class="text-capitalize"></td><td id='check_balance' class="text-capitalize"></td><td id='description' class="text-capitalize"></td><td><span class="btn-primary btn displays update" onclick="Update(this)" id="update"><i class="far fa-edit"></i>Update</span><span class="btn-primary btn edit" onclick="Edit(this)" id="update"><i class="far fa-edit"></i>Edit</span><span onclick="Delete(this)" class="btn-danger delete btn"  id="delete"><i class="fas fa-trash-alt"></i>delete</span></td></tr>`
                    t = $('thead [type=hidden]').val()
                    console.log(t)
                    console.log(result.data)
                    table(t,result,$("table"))
                    break;
            }

            $('.msg').text(result.message)

            $('form').find('input').val('')

        },    
        error : function(err)    {
                $('.msg').text('')
                $('.msg').text(err.responseJSON.message)  
        },

    }).always(function(err) {              console.log(err)

        
        totop()
        loading()
    })

})
function table(row,data,table){
    $this= $(table)
     th=$this.find('thead tr').find('th');
     arrTh= [];
    for(var x = 0; x < th.length; x++ ){
        arrTh.push($(th[x]).attr('id'))
    }
    console.log(data)
    $.each(data , function(id,state){
        $this.find('tbody').append((row))
        for(a =0; a < arrTh.length; a++){
            $($this.find('tbody tr:last-child').find('td')[a]).text(state[arrTh[a]])
        }
    })
}



$('.validate').blur(function(e){
    // e.preventDafault()
     acc=$(this).val();
     dat=$(this).parent().parent();
     //type=(dat.find('[name=type]')).val().toLowerCase()
     dat.find('#submit').attr('disabled','')
//     //console.log(aja('serviceCode=V-Internet&type=SMILE&account=1402000567'))
     $.ajax({
         url:$(dat).find('#validate').val(),
         data:dat.serialize(),
         type:'GET',
         beforeSend : function()    { 
             dat.find('.valid-container').removeClass('spinner-grow').addClass('spinner-grow').find('span').text('');
    },
         error : function(err)    {
                 dat.find('.valid-container').removeClass('spinner-grow').find('span').text('Check Network Connectivity');
                 if(err.status == 422){
                    dat.find('.valid-container').removeClass('spinner-grow').find('span').text('Required data not supplied');
                 }
                },
         success:function(result){

             if(result.success==true){
                 dat.find('span.valid').text('Customer Name: '+result.message).parent().removeClass('spinner-grow')
                 dat.find('#submit').removeAttr('disabled')
             }else{
                 dat.find('span.valid').text(result.message).parent().removeClass('spinner-grow') 
             }
 
         }
 
     })
     
 })


 function refund(id){
    $this = event.target

    loaded();
     $.ajax({
         type:'get',
         data:'id='+id,
         url:"/admin/refund"
     }).done(function(data){
        console.log(data)
        $('.msg').text(data.message)
        
        $($this).parent().addClass('d-none')
        console.log(event.target)
        totop()
     }).always(function(data){
        $('.msg').text(data.message)
        console.log(data)
        loading()
     }).fails(function(err){
        $('.msg').text(err.responseJSON.message)  
        
    })
    }

 function complete(id){
     $this = event.target
    loaded();
    $.ajax({
        type:'get',
        data:'id='+id,
        url:"/admin/complete"
    }).done(function(data){
        $('.msg').text(data.message)
        totop()
        $($this).parent().hide()
    }).always(function(data){
        $('.msg').text(data.message)
        loading()

    }).fails(function(err){
        $('.msg').text(err.responseJSON.message)  

    })
}

  function  checkTransaction(event){
     var ref= event.target
     var reference;
      reference= $(ref).parent().parent().find('.reference').text()
      loaded()
      $.ajax({
          'type':'GET',
          'url':'/rave/'+reference,
          'data':'ref='+reference
      }).done(function(data){
        console.log(data)
          if(data.status == true){
          $('#custname').text(data.data.custname)
          $('#custemail').text(data.data.custemail)
          $('#fraudstatus').text(data.data.fraudstatus)
          $('#type').text(data.data.card.type)
          $('#issuing_country').text(data.data.card.issuing_country)
          $('#cardBIN').text(data.data.card.cardBIN)
          $('#last4digits').text(data.data.card.last4digits)
          $('.modal').modal('show')
          }else{
              $('.msg').text(data.message)
              totop()
          }
      }).always(function(data){
          loading()
      }).fail(function(err){
        $('.msg').text(err.responseJSON.message)  

    })
  }

function totop(){
    $('html ,body').animate({
        scrollTop:0
    },1000)
}
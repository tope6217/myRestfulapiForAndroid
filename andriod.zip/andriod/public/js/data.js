
d={
type:'',
status:''
}


$('#dtype').change(function(){
console.log(data)
d.type=$(this).val();

console.log(d.type)
$('#damount').empty()
$('#damount').html("<option>select amount </option>")

for(i=0;i<data.length;i++){
if(data[i].network_id==d.type){
$('#damount').append($('<option/>').val(data[i].id).text(data[i].amount+' '+data[i].description))
}
}
})


$('#damount').change(function(){
dd=$(this).val();
console.log(data)
for(i=0;i<data.length;i++){
if(data[i].id==dd){
console.log(data[i].price)
$('#dprice').val(data[i].price)
}
}
})
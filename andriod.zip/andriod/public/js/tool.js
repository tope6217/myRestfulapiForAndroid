var tool = $('#tool').val()
len  = $('.check');

function enter(){
splited = JSON.parse(tool);
$.each(splited,function(id,split){
  for (let index = 0; index < len.length; index++) {
    if($(len[index]).val() == split) {
      $(len[index]).attr('checked','checked')
    }     
  console.log($(len[index]) ) 
  }
})
}
enter()

$('#category').change()
$('.check').change(function(){
  var a =""
  leng = len.length;
  for (let index = 0; index < leng; index++) {   
        
    if($(len[index]).is(':checked')) {
     a = a + $(len[index]).val()+'|';
    }
  }
  a_store =a.substring(0,a.length-1)
  $('#tool').val(a_store)
})
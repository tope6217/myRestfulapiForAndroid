$('.nav-item').click(function(){
    $('.nav-item').find('.nav-link').removeClass('active')
    $(this).find('.nav-link').addClass('active')
    $('.bin').addClass('form-hide')
    var show =$(this).find('.nav-link').attr('name')
    $('#'+show).removeClass('form-hide')
})
$(function () {
    $('.metisFolder').metisMenu({
        toggle: false
    });
});

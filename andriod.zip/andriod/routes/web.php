<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//Route::get('forgot_password', 'auth.reset_password')->name('password.reset');


Route::get('/login','adminController@index')->name('login');

Route::post('/login','adminController@login')->name('login');

Route::middleware(['auth:web'])->prefix('/admin')->group(function () {

    Route::resource('/electricity', 'ElectricityController');
    Route::resource('/airtime' , 'AirtimeController');
    Route::resource('/network' , 'NetworkController');
    Route::resource('/cableTv' , 'CabletvController');
    Route::resource('/cable' , 'CableController');
    Route::resource('/data' , 'DataController');
    Route::get('/credit' , 'TransactionController@view_credit')->name('credit');
    Route::get('/credit/transaction','adminPageController@credit_v')->name('credit_view');
    Route::get('/api','adminPageController@apiss')->name('api');
    Route::get('/today/debit','adminPageController@today_debit')->name('todayDebit');
    Route::get('/today/credit','adminPageController@today_credit')->name('todayCredit');
    Route::get('/refunded','TransactionController@refunded')->name('refunded');
    Route::get('/unsettled','adminPageController@unsettled')->name('unsettled');
    Route::get('/refund','TransactionController@refund');//refund
    Route::get('/complete','TransactionController@complete');//refund
    Route::post('/message','TransactionController@message_users')->name('messages');
    Route::get('/message','TransactionController@message_user')->name('message');
    Route::get('/transaction','TransactionController@view_debit')->name('debit');
    Route::get('/detail','adminController@admin')->name('admin');
    Route::get('/logout','adminController@logout')->name('logout');


    Route::get('/today/debit','adminPageController@today_debit')->name('todayDebit');
    Route::get('/today/credit','adminPageController@today_credit')->name('todayCredit');
    Route::get('/refunded','adminPageController@refunded')->name('refunded');
    Route::get('/unsettled','adminPageController@unsettled')->name('unsettled');
    Route::get('/search','adminPageController@search')->name('search');
    Route::get('/index','adminController@admin_index');
    Route::get('/api','adminPageController@apiss')->name('api');
    Route::post('/update/api','adminPageController@api');


    //users
    Route::post('/internet/recharge/purchase' , 'InternetData@airtime')->name('internetAirtimepurchase');
    Route::post('/internet/data/purchase' , 'InternetData@data')->name('internetDatapurchase');
    Route::get('/user/debit/{id}','UsersController@userDebit');
    Route::get('/user/credit/{id}','UsersController@userCredit');
    Route::get('/users/','UsersController@user')->name('users');

    Route::post('/cabletv/purcharse','TvController@Tv')->name('cabletvPurchase');
    Route::post('/electricity/purchase','ElectricController@buy')->name('electricityPurcharse');
    Route::post('/data/purcharse','RechargesController@data')->name('dataPurchase');
    Route::post('/airtime/purcharse','RechargesController@airtime')->name('airtimePurchase');
    Route::resource('internet', 'internetController');
    Route::resource('internetdata', 'internetDataController');
    Route::resource('internetairtime', 'InternetAirtimesController');


});
Route::post('/pay', 'RaveController@initialize')->name('pay');
Route::get('/rave/callback/{ref}', 'RaveController@verify')->name('callback');
Route::get('/rave/{ref}', 'RaveController@data');



Route::middleware(['auth:web'])->prefix('/validate')->group(function () {

Route::get('internet/recharge/validate' , 'InternetData@validateRonsponses')->name('internetV');
Route::get('electricity/validate','ElectricController@validateRonsponses')->name('electricV');
Route::get('cabletv/validate','TvController@validateRonsponses')->name('cableTvV');
});
// Route::get('/login','U');
//Route::get('/login','adminController@index')->name('login');
//Route::post('/login','adminController@login')->name('login');
//Route::get('/admin/detail','adminController@admin')->name('admin');

//Route::get('/payment','questionController@userworkout');
//Route::get('/test','RechargesController@network');

// Route::middleware(['auth:web'])->prefix('/admin')->group(function () {

// });

Route::get('/migrate', function(){
    \Artisan::call('route:clear');
    \Artisan::call('view:clear');
    \Artisan::call('cache:clear');
    \Artisan::call('migrate');
    dd('migrated');
});

Route::get('/home', 'HomeController@index')->name('home');

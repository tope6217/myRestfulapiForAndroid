<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });

Route::get('/user/email/verify/{id}', 'VerificationController@verify')->name('verification.verify'); // Make sure to keep this as your route name
Route::get('/user/email/resend', 'VerificationController@resend')->name('verification.resend');
Route::post('/user/password/email', 'ForgotPasswordController@forgot');
Route::post('/user/password/reset/', 'ForgotPasswordController@reset')->name('password.reset');
Route::middleware(['middleware' => 'auth:api'])->prefix('/user')->group(function ($router) {
    Route::post('/logout', 'AuthController@logout');
    Route::post('/refresh', 'AuthController@refresh');
    Route::post('/me', 'AuthController@me');
    Route::post('/cabletv/purcharse','TvController@Tv');
    Route::post('/electricity/purchase','ElectricController@buy');
    Route::post('/data/purcharse','RechargesController@data');
    Route::post('/airtime/purcharse','RechargesController@airtime');
    Route::post('/internet/data/purchase' , 'InternetData@data');
    Route::post('/internet/recharge/purchase' , 'InternetData@airtime');
    Route::get('/callback', 'RaveController@callback')->name('callback');
    Route::get('/pay','paymentController@initallizePayment');
    Route::post('/internet/recharge/validate' , 'InternetData@validateRonsponses');
    Route::post('/electricity/validate','ElectricController@validateRonsponses');
    Route::post('/cabletv/validate','TvController@validateRonsponses');
    Route::get('/credit', 'AuthController@credit');
    Route::get('/debit', 'AuthController@debit');
});
Route::get('/electricity', 'ElectricController@product');
Route::get('/cableTv', 'TvController@product');
Route::get('/data', 'RechargesController@network');
Route::get('/airtime', 'RechargesController@FindAirtime');//FindAirtime
Route::get('/internet/data', 'internetData@networks');//FindAirtime productAirtime
Route::get('/internet/airtime', 'internetData@productAirtime');//FindAirtime productAirtime

//networks productAirtime
//TvController@product

Route::post('/user/register', 'AuthController@Register');
Route::post('/user/login', 'AuthController@login');


<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class smile extends Model
{
    
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\userWorkout;
use App\workout;
use App\tool;
use App\User;
use App\apiss;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Config;
class responses extends Model
{
    use ValidatesRequests;
    public function general($status,$error,$message,$code,$data){
        if($status == true){
            return response()->json(['message'=>$message,'success'=>$status,'data'=>$data,'code'=>$code]);
        }
        return  response()->json(['message'=>$error,'success'=>$status,'error'=>$error,'code'=>$code]);
    }



    public function validatedatas($responseArr){
        $returnResponse = $this->customer_api(config::get('app.internet_data'),$responseArr);
        if( $returnResponse=='200'){
           return $this->general(true,null,$returnResponse['message'],200,$returnResponse);
        }else{
           return $this->general(false,$returnResponse['message'],'successful',200,$returnResponse);
        }
    }

    public function loader($responseArr){
      return  $returnResponse = $this->customer_api(config::get('app.internet_data'),$responseArr);
    }

    public function customer_api($url,$data){
        return    Http::withHeaders([
                'email' => $this->ap()[0]->email,
                'password' => $this->ap()[0]->passwordorapi,
                'Content-Type'=> 'application/json'
            ])->post($url,($data));
         }


         public function apii($url,$api_token,$json_data){
            $curl = curl_init();
            curl_setopt_array(
                $curl, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,  
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS =>$json_data,
                CURLOPT_HTTPHEADER => [ 
                    "authorization: $api_token", //replace this with your own test key
                    "content-type: application/json",
                "cache-control: no-cache"
                ],
            )
        );
        $response = curl_exec($curl);
        $err = curl_error($curl);
        if($err){
            dd($err);
        }

        return ($response);
    }

         public function isSufficient($product_price){
            // return $product_price;
             if(auth()->user()->amount >= $product_price){
                 return true;
             }
             return false;
         }

         public function inSuficientResponse(){
            return $this->general(false,'Insufficient fund credit your account','',100,'');
         }

         public function debit($product_price){
             $amount = Auth()->user()->amount - $product_price;
             User::where('id' , Auth()->user()->id)->update([
                 'amount' => $amount
             ]);
             return true;
         }

         public function datet(){
             return date('Y/m/d');
         }

         public function storeDebit($category,$product_name,$quantity,$product_amount,$charges,$debited_price,$reference,$status,$description,$amount,$re_balance,$json,$request_id,$destination,$price){
             $debit = new debit();
             $debit->category =  $category;
             $debit->product_name = $product_name;
             $debit->quantity =  $quantity;
             $debit->product_amount =  $product_amount;
             $debit->charges =  $charges;
             $debit->debited_price = $debited_price; 
             $debit->reference =  $reference;
             $debit->re_balance =  Auth()->user()->amount;
             $debit->json =  json_encode($json);
             $debit->user_id =  Auth()->user()->id;
             $debit->status =  $status;
             $debit->request_id = $request_id;
             $debit->description =  $description;
             $debit->amount = $amount;
             $debit->destination = $destination;
             $debit->price = $price;
             $debit->date = $this->datet();
             if($debit->save()){
                 return true;
             };
             return false;
         }

        public function ap(){
            $ap =new apiss(); 
            return $ap->select()->get();
        }
        


         public function notify($form){
            $notification=new notification();
            return  $notification->create($form);
         }
}

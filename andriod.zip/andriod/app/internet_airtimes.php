<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class internet_airtimes extends Model
{
    public function internet(){
        return $this->belongsTo('App\internet');
    }
}

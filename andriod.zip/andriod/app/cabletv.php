<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;

class cabletv extends Model
{
    //
    use Notifiable;
    protected $fillable = [
        'type','code','price','charges','rate','blocked','name'
    ];


    public function cable(){
        return $this->belongsTo('App\cable');
    }
/**
 * The attributes that should be hidden for arrays.
 *
 * @var array
 */
protected $hidden = [
    'password', 'remember_token',
];

/**
 * The attributes that should be cast to native types.
 *
 * @var array
 */
protected $casts = [
    'email_verified_at' => 'datetime',
];
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class internet_data extends Model
{
    public function data(){
        return $this->hasMany('App\internet_data');
    }

    public function internet(){
       return $this->belongsTo('App\internet');
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;
use App\debit;
use App\credit;
use App\datas;
use App\electricities;
use App\airtime;
use App\cabletv;
class adminController extends Controller
{
    public function index(){
        return view('login');
    }



    public function logout(){
        \Auth::guard('web')->logout();
        return redirect(route('login'));
    }


    public function admin(){
        $users = count(user::all());
        $debit = count(debit::all());
        $credit = count(credit::all());
        $data = count(datas::all());
        $airtime = count(airtime::all());
        $electricity = count(electricities::all());
        $cable = count(cabletv::all());
        $amount = User::where('type','member')->sum('amount');
        $purchase = debit::where('user_id','!=','1')->sum('debited_price');
        $total_credit = credit::where('user_id','!=','1')->sum('amount');
        return view('admin.index')->with([
            'users' => $users,
            'debit' => $debit,
            'credit' => $credit,
            'data' => $data,
            'electricity' => $electricity,
            'airtime' => $airtime,
            'cable' =>$cable,
            'total_amount' => $amount,
            'total_purchase' => $purchase,
            'total_credit' => $total_credit
        ]);
        }

    public function login(Request $request){
        $this->validate($request , [
            'email' => 'required|email',
            'password' => 'required'
        ]);
      //  $request->type = 'admin';
       // return $request->all();
       // $credentials = $request->only('email', 'password','role');
        if (Auth::guard('web')->attempt(['email' => $request->email , 'password' => $request->password ,'type' => 'admin'])) {
            $request->session()->regenerate();
            return redirect(route('admin'));
        }else{
            return back()->with([
                'error' => true,
                'msg' => 'Invalid login details'
            ]);
        }
    }

    public function admin_index(){
        return view('admin.admin_index')->with([
            'customers' => User::all()
        ]);
    }
}

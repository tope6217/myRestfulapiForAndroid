<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use Srmklive\PayPal\Services\PayPal as PayPalClient;
use App\responses;
use App\userWorkout;
use App\subscribtion;
use App\payment;
class paymentController extends Controller
{
    public function __construct()
    {
        $this->middleware('verified');
    }

    public function initallizePayment(Request $request){
        if(empty(auth()->user()->survey)){
            return redirect(route('question'));
        }
        $this->validate($request , [
            'subscribtion_id' => 'required|integer'
        ]);
        $reference = rand(1,20);
        //dd($reference);
        $responses = new responses();
        $payment = new payment();
        $payment_store = $payment->where('reference',$reference)->get();
       // dd(count($payment_store));
        $subscribtion_id = $request->subscribtion_id;
        $subscribtion = subscribtion::where('id',$subscribtion_id)->first();
        if(empty($subscribtion)){
            return $responses->general(false,'invalid Subscribtion id','',201,'');
        }
        $user_id = auth()->user()->id;
        $payment->reference = $reference;
        $payment->user_id = $user_id;
        $payment->subscribtion_id = $subscribtion_id;
        $payment->amount = $subscribtion->amount;
        if($payment->save()){
            $payment_store = payment::where('reference',$payment->reference)->first();
            
            if($responses->storeUserWorkout($payment_store->id,$user_id,$subscribtion->id) == true){
               return $responses->general(true,'','Payment successfull',200,'');
            };
        }

    }

    public function pay(){

    }
    public function complete(){
        $responses = new responses();
         return $responses->unexpiring_date(1);
    }
}

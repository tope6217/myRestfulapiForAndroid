<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Config;
use App\responses;
class testController extends Controller
{

}

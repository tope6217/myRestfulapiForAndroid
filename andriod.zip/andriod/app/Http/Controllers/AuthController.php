<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\User;
use App\question;
use App\payment;
use App\subscribtion;
use App\category;
use JWTAuth;
use App\responses;
use App\debit;
use App\credit;
use Config;

class AuthController extends Controller
{
    /**
     * Create a new AuthController instance.
     *
     * @return void
     */
    public function __construct()
    {
       // $this->middleware('verified')->only('question');
    }

    /**
     * Get a JWT via given credentials.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function login(Request $request)
    {
        $token =Null;
        $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);
        $credentials = $request->only(['email', 'password']);

        if (!$token = JWTAuth::attempt($credentials)) {
            return response()->json(['error' => 'unauthorized'],401);
        }

        return $this->respondWithToken($token);
    }

     public function Register(Request $request){
         $request->isPremium = false;
         $response = new responses();
         $request->validate([
            'name' => "required|string|max:255",
            'email' => "required|string|email|max:255|unique:users",
            'password' => "required|string|min:8|confirmed",
            'phone' => "required|string|unique:users|min:11|max:11"
        ]);


            $user = new user();
            $user->name = $request->name;
            $user->email = $request->email;
            $user->phone = $request->phone;
            $user->password = bcrypt($request->password);
            try {
             $user->save();
             user::where('email',$request->email)->get()->first()->sendEmailVerificationNotification();
            } catch (Exception $e) {
            }
    
         return  $response->general(true,null,'Register successful','200',$request->all());


     }



    /**
     * Get the authenticated User.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function me()
    {
        $response = new responses();
        return  $response->general(true,null,'login successfull','200',auth()->user());
    }

    /**
     * Log the user out (Invalidate the token).
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout()
    {
        $response = new responses();
        auth()->logout();
        return  $response->general(true,null,'logout successfull','200','');
    }

    /**
     * Refresh a token.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function refresh()
    {
        return $this->respondWithToken(auth()->refresh());
    }



    public function debit(){
        $debit = new debit();
        $response = new responses();
        return $response->general(true,null,'successful',200,$debit->where('user_id',auth()->user()->id)->paginate(config::get('app.paginate')));
    }

    public function credit(){
        $credit = new credit();
        $response = new responses();
        return $response->general(true,null,'successful',200,$credit->where('user_id',auth()->user()->id)->paginate(config::get('app.paginate')));
    }


    /**
     * Get the token array structure.
     *
     * @param  string $token
     *
     * @return \Illuminate\Http\JsonResponse
     */
    protected function respondWithToken($token)
    {
        return response()->json([
            'status' => true,
            'message' => 'login successfull',
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth()->factory()->getTTL() * 60
        ]);
    }

    public function userPayment(){
        return payment::where('id',auth()->user()->id)->with('subscrition')->get();
    }

    public function subscribtion(){
        return subscribtion::all();
    }

}
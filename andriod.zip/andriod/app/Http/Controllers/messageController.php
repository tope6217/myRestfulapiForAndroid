<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\message;
use Illuminate\Support\Facades\Validator;

class messageController extends Controller
{
    public function message(Request $req){
        $validator = Validator::make($req->all(), [
            'password' => 'required',
            'email' => 'required',
        ]);
    
        if ($validator->fails()) {
            $validator->errors()->all();
            $this->responses('202');
         }
         if($this->Customer_details($req)!=false){
          $user_id =  $this->Customer_details($req)->id;
             $messages=new message();
             return $messages->where('user_id',$user_id)->select()->get();
         }
    }
}
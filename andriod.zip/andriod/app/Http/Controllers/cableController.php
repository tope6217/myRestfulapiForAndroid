<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\cable;
use App\responses;
class cableController extends Controller
{


    public function __construct(){
        $this->middleware('admin');
    }


    public function index()
    {
        return view('admin.cable')->with([
            'cables' => cable::all()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    private function direct(){
        return redirect(route('cable.index'))->with([
            'success' => true,
            'msg' => 'updated'
        ]);
    }


    private function validaterequest($request){
        $this->validate($request , [
            'name' => 'required',
        ]);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validaterequest($request);
        $cable = new cable();
        $cable->name = $request->name;
        $cable->blocked = $request->blocked;
        $cable->save();
     return   $this->direct();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $cable = new cable();
        $response = new responses();
      return  $response->general(true,'','',200,$cable->where('id',$id)->get());
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validaterequest($request);
        $cable = new cable();
        $cable->where('id',$id)->update([
            'name' => $request->name,
            'blocked' => $request->blocked
        ]);
        return $this->direct();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\debit;
use App\credit;
use App\User;
use App\responses;
use App\message;
use Config;
class TransactionController extends Controller
{
    private $debit ,$credit;
    public function __construct(){
        $this->debit = new debit();
        $this->credit = new credit();
        $this->middleware('admin');

    }

    public function debit(){
        return $this->debit->get();
    }

    public function view_debit(){
        //return $debit->json();
       // dd($debit->count());
        return view('admin.transactions')->with([
            'debits' => $this->debit->with('user')->paginate(config::get('app.paginate'))
        ]);
    }

    public function view_credit(){
        return view('admin.credit')->with([
            'credits' => $this->credit->paginate(config::get('app.paginate'))
        ]);
    }



public function user_val(Request $req){
  return  user::where('email',$req->id)->orWhere('phone',$req->id)->get();
}
public function credit_v(){

    return view('credit_view')->with([
        'credits'=>credit::orderBy('id','DESC')->get()
    ]);
  }

  public function apiss(){
    return view('apiKey')->with([
        'apis'=>apiss::orderBy('id','DESC')->get()
    ]);
  }

  public function today_debit(){
      $date = date('Y-m-d');
    return view('transaction')->with([
        'debits'=>debit::where('date',$date)->with('user')->orderBy('id','DESC')->get()
    ]);
  }

  public function today_credit(){
   $date = date('Y-m-d');
  return view('credit_view')->with([
      'credits'=>credit::where('date',$date)->orderBy('id','DESC')->get()
  ]);
}

public function refunded(){
  return view('transaction')->with([
      'debits'=>debit::where('refunded',true)->orderBy('id','DESC')->get()
  ]);
}

public function unsettled(){
  return view('transaction')->with([
    'debits'=>debit::where('refunded',0)->where('status',0)->orderBy('id','DESC')->get()
]);
}

  public function refund(Request $req){
      $response = new responses();
    $debit =  debit::where('id',$req->id)->get()[0];
    $reference = $debit->request_id;
   $credit_find = credit::where('reference',$reference)->get();
   if($debit->status == 1){
    return $response->genenal(true,'','transaction successful',200,[]);
   }
   if(count($credit_find) == 0)
   {
    $credit['user_id'] = $debit->user_id;
    $credit['reference'] = $debit->request_id;
    $credit['amount'] = $debit->amount;
    $credit['isrefund'] = true;
    $credit['date'] =$response->datet();
 // return  $credit;
    $amount_to_credit = user::where('id',$credit['user_id'])->select('amount')->get()[0]->amount + $debit->amount;
    user::where('id',$debit->user_id)->update([
        'amount' =>$amount_to_credit
    ]);
    $debit->where('id',$req->id)->update(['refunded'=>true]);
    credit::create($credit);
    $this->message($credit['user_id'],'Unsuccessful Transaction',$debit->amount."You request to pay for N".$debit->amount." ".$debit->product_name." bill into meter number ".$debit->destination."was  not successful and ".$debit->amount." has been refunded to your account.
    Thanks for trusting us.
    You can always contact us from the contact page.
    With care from the Afiq Teller team.");
    return $response->general(true,'','Transaction successful',200,[]);
}else{
    return $response->general(true,'Already done','',201,[]);
}
}

public  function complete(Request $req){
    $response = new responses();

    $user_id = debit::where('id',$req->id)->select('user_id')->get()[0]->user_id;
  $trans=  debit::where('id',$req->id)->get()->first();
    debit::where('id',$req->id)->update([
        'status' =>true
    ]); 
    $this->message($user_id,'successful Transaction ',"Message: You request to pay for N".$trans->amount.' '.$trans->product_name.' bill into meter number '.$trans->destination." was successful.
    Thanks for trusting us.
    With care from the Afiq Teller team.");
    return $response->general(true,'','Transaction successful',200,[]);

}

public function message_user(){
    return view('admin.message')->with([
        'users'=>User::get()
    ]);
}

public function message_users(Request $req){
    $response = new responses();
    if(empty($req->id)){
       $users = User::get();
       foreach ($users as $user) {
        $this->message($user->id,$req->topic,$req->message);
       }
       return $response->general(true,'','Transaction successful',200,[]);
    }
    $this->message($req->id,$req->topic,$req->message);
    return $response->general(true,'','Transaction successful',200,[]);

}

public function message($user_id,$topic,$message){
    $mes['user_id'] = $user_id;
    $mes['topic'] = $topic;
    $mes['message'] = $message;
    message::create($mes);
}
}


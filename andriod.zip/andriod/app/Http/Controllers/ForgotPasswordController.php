<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Password;
use Illuminate\Http\Request;
use App\responses;

class ForgotPasswordController extends Controller
{
    public function forgot() {

        $response = new responses();
        $credentials = request()->validate(['email' => 'required|email']);
        $data = Password::sendResetLink($credentials);
        return $data == Password::RESET_LINK_SENT
            ? $response->general(true,'Reset link sent to your email.','Reset link sent to your email.','200','')
            : $response->general(false,'Unable to send reset link','Unable to send reset link','400','');
    }


    public function reset() {
        $response = new responses();
        $credentials = request()->validate([
            'email' => 'required|email',
            'token' => 'required|string',
            'password' => 'required|string|confirmed'
        ]);

        $reset_password_status = Password::reset($credentials, function ($user, $password) {
            $user->password = $password;
            $user->save();
        });

        if ($reset_password_status == Password::INVALID_TOKEN) {
           return $response->general(false,'Invalid token provided','Invalid token provided','400','');
        }

      return  $response->general(true,'Password has been successfully changed','Password has been successfully changed','200','');
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\internet;
use App\internet_data;
use App\responses;

class InternetDataController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

     
     public function direct(){
         return redirect(route('internetdata.index'));
     }

     public function validateRequest($request){
         $this->validate($request , [
             'internet_id'=>'required',
             'price'=>'required',
             'name'=>'required',
             'validity'=>'required',
             'code'=>'required',
             'validateCode'=>'required',
             'charges'=>'allowance'
         ]);
     }
    public function index()
    {
        return view('admin.internetdata')->with([
            'internets' => internet::all(),
            'datas' => internet_data::all()
        ]);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validateRequest($request);
        $internet_data = new internet_data();
        $internet_data->internet_id = $request->internet_id;
        $internet_data->price = $request->price;
        $internet_data->name = $request->name;
        $internet_data->validity = $request->validity;
        $internet_data->code = $request->code;
        $internet_data->validateCode = $request->validateCode;
        $internet_data->charges = $request->charges;
        $internet_data->save();
        return $this->direct();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\internet_data  $internet_data
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $response = new responses();
        
        return $response->general(true,'','successful',200,internet_data::where('id',$id)->get());

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\internet_data  $internet_data
     * @return \Illuminate\Http\Response
     */
    public function edit(internet_data $internet_data)
    {
        //
    }

    
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\internet_data  $internet_data
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        internet_data::where('id',$id)->update([
            'internet_id' => $request->internet_id,
            'price' => $request->price,
            'name' => $request->name,
           'validity' => $request->validity,
            'code' => $request->code,
            'validateCode' => $request->validateCode,
            'charges' => $request->charges,
            'message' => ''

        ]);
        return $this->direct()->with([
            'success' => true,
            'msg' => 'updated'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\internet_data  $internet_data
     * @return \Illuminate\Http\Response
     */
    public function destroy(internet_data $internet_data)
    {
        //
    }
}

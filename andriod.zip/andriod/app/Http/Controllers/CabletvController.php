<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\cabletv;
use App\responses;
use App\cable;
class CabletvController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct(){
        $this->middleware('admin');
    }

    public function index()
    {
        return view('admin.cableTv')->with([
            'cables' => cabletv::with('cable')->get(),
            'cableTypes' => cable::all()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    private function validateRequest($request){
        $this->validate($request , [
            'cable_id' => 'required',
            'code' => 'required',
            'price' => 'required',
            'charges' => 'required',
        ]);

    }
    private function direct(){
        return redirect(route('cableTv.index'))->with([
            'success' => true,
            'msg' => 'updated'
        ]);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validateRequest($request);
        $cableTv = new cableTv();
        $cableTv->cable_id = $request->cable_id;
        $cableTv->code = $request->code;
        $cableTv->price = $request->price;
        $cableTv->charges = $request->charges;
        $cableTv->save();
       return $this->direct();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       $response = new responses();
       $cableTv = new cableTv();
       return $response->general(true,'','success',200,$cableTv::where('id',$id)->get());
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validateRequest($request);
        $cableTv = new cableTv();
        $cableTv->where('id' , $id)->update([
            'cable_id' => $request->cable_id,
            'code' => $request->code,
            'price'=> $request->price,
            'charges' => $request->charges,
        ]);
       return $this->direct();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\airtime;
use App\datas;
use App\recharge;
use App\network;
use App\electricities;
use App\cabletv;
use App\smile;
use App\debit;
use App\message;
use App\notification;
use App\apiss;
use App\credit;
use App\responses;
use Config;

class adminPageController extends Controller
{

    public function __construct(){
       $this->middleware('admin');
    }

    
    public function apiss(){
      return view('admin.apiKey')->with([
          'apis'=>apiss::orderBy('id','DESC')->get()
      ]);
    }

    public function api(Request $req){
     // return $req->all();
      apiss::where('id',$req->id)->update([
        'email' => $req->email,
        'passwordorapi' => $req->passwordorapi
      ]);

      $responses = new responses();
      return $responses->general(true,'','updated',200,[]);
  }

    public function user_val(Request $req){
      return  user::where('email',$req->id)->orWhere('phone',$req->id)->paginate(config::get('app.paginate'));
    }
    public function credit_v(){

        return view('credit_view')->with([
            'credits'=>credit::orderBy('id','DESC')->paginate(config::get('app.paginate'))
        ]);
      }



      public function today_debit(){
        $responses = new responses();
        $date = $responses->datet();

        return view('admin.transactions')->with([
            'debits'=>debit::where('date',$date)->orderBy('id','DESC')->paginate(config::get('app.paginate'))
        ]);
      }

      public function today_credit(){
          $responses = new responses();
       $date = $responses->datet();
      return view('admin.credit_view')->with([
          'credits'=>credit::where('date',$date)->orderBy('id','DESC')->paginate(config::get('app.paginate'))
      ]);
    }

    public function refunded(){
      return view('admin.transactions')->with([
          'debits'=>debit::where('refunded',true)->orderBy('id','DESC')->paginate(config::get('app.paginate'))
      ]);
    }

    public function unsettled(){
      return view('admin.transactions')->with([
        'debits'=>debit::where('refunded',0)->where('status',0)->orderBy('id','DESC')->paginate(config::get('app.paginate'))
    ]);
  }

    public function message_user(){
        return view('message')->with([
            'users'=>User::get()
        ]);
    }

    public function search(Request $req){
      $debit = new  debit();
      $credit =  new credit();
      //return $req->all();
      if(!empty($req->date)){
          $debit = $debit->where('date',$req->date);
          $credit = $credit->where('date',$req->date);
         // return $req->date;
      }
      
      $user = User::where('email',$req->email)->orWhere('name',$req->name)->get();
      if(count($user) > 0){
          $user_id = $user[0]->id;
          $debit = $debit->where('user_id',$user_id);
          $credit = $credit->where('user_id',$user_id); 
      }
      if(!empty($req->reference)){
          $debit = $debit->where('reference',$req->reference);
          $credit = $credit->where('reference',$req->reference);
          $response['debit']= $debit->get();
          $response['credit'] = $credit->get();
      return $response;
      }
          $response['debit']= $debit->get();
          $response['credit'] = $credit->get();
      return $response;
  }

  
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Config;
use App\debit;
use App\credit;
class UsersController extends Controller
{
    public function __construct(){

        $this->middleware('admin');

    }
    public function user(){
        return view('admin.user')->with([
            'users' => user::paginate(config::get('app.paginate'))
        ]);
    }

    public function userDebit($id){
        return view('admin.transactions')->with([
            'debits' => debit::where('user_id',$id)->paginate(config::get('app.paginate'))
        ]);
    }

    public function userCredit($id){
        return view('admin.credit_view')->with([
            'credits' => credit::where('user_id',$id)->paginate(config::get('app.paginate'))
        ]);
    }
}

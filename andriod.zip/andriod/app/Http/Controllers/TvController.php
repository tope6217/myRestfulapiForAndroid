<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\cable;
use App\cabletv;
use App\responses;
use Config;
class TvController extends Controller
{
    public function __construct(){
        $this->middleware('verified',['except'=>['product']]);
    }
    
    public function product(){
        return cable::where('blocked',0)->with('cables')->get();
    }

    
    public function product_confirmed($request){

        $product = new cabletv();
        return $product->where('blocked',0)->where('id',$request->tv_id)->with('cable')->select()->get();
    }

    protected function request_id($length = 18) {
        return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
    }
    
    public function validateRonsponses(Request $request){
        $this->validate($request , [
          'tv_id' => 'required',
         'smartCardNo' => 'required'
        ]);
        $response = new responses();
        $data = $this->product_confirmed($request)[0];
        $responseArr = ['serviceCode' => $data->validateCode, 'smartCardNo' => $request->smartCardNo , 'type'=>$data->cable->name ,'request_id'=>$this->request_id()];       return $returnResponse = $response->validatedatas($responseArr);
      }

    public function Tv(Request $request){// "username=08109319667&password=19966141&period=2&smartCardNo=10441003943&name=GOtv Smallie - monthly&type=GOTV"
        //return $req->all();
        $response = new responses();
         $this->validate($request, [
            'smartCardNo'=>'required',
            'period'=>'required',
            'tv_id'=>'required'
        ]);

        $product_details=$this->product_confirmed($request);

       if(count($product_details) <= 0){
           return $response->general(false,'Not Available For now','',99,[]);
        }
       $request_id=$this->request_id();
          $product_details=$product_details[0];
        $price_to_pay =  $product_details->charges + ($product_details->price * $request->period);
        $requestParameter = ([
            'serviceCode' => $product_details->serviceCode , 'request_id'=>$request_id , 'code' => $product_details->code , 'smartCardNo' => $request->smartCardNo, 'type' => $product_details->cable->name, 'hasAddon' =>false, 'period' => $request->period ,'name' => 'Asian Add-on', 'addoncode' =>'ASIADDE36'
        ]);
        //return $requestParameter;
        if(Auth()->user()->type == 'member'){
      $isSufficient = $response->isSufficient($price_to_pay);
       if($isSufficient != true){
           return $response->inSuficientResponse();
       }
    }

      $res = $response->customer_api(config::get('app.tv'),$requestParameter);
   // $res = json_decode($res,true);
             $charges = $price_to_pay-$product_details->price;
        if($res['status'] == 200){
            $response['amount'] = $price_to_pay;
            $responseDetails = json_decode($res,true);
            $amountCharged= $res['amountCharged']/$request->period;
           if (($amountCharged) > $price_to_pay){
            $cable=new cabletv();
            $cable->where('id',$product_details->id)->update(['price'=>$amountCharged,'message'=>'software_update']);
            $price_to_pay=$res['amountCharged']+$x_charges;
            $response['amount'] = $price_to_pay;
        }
        $response->debit($price_to_pay);//debit customer
        $response->storeDebit('cabletv',$product_details->cable->name,$request->period,$product_details->price,$charges,$price_to_pay,$res['transref'],true,'done',$product_details->price,auth()->user()->amount,$res,$request_id,$request->smartCardNo,$price_to_pay);
            return $response->general(true,'','Transaction successfull',200,[]);
        }elseif($res['status']==300){
            $note=  ["on"=>'ringo','notification'=>$res['message'],['message']=>"'".$res."'",'read'=>false];
            $this->notify($note);
            return $response->general(false,'Check back later','Transaction successfull',99,[]);

        }else{
            return $response->general(false,'Check back later','Transaction successfull',99,[]);
        }
}
}

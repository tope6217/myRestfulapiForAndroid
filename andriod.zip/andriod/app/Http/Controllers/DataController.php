<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\responses;
use App\datas;
use App\network;
class DataController extends Controller
{

    public function __construct(){
        $this->middleware('verified');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */




    public function index()
    {
        return view('admin.data')->with([
            'datas' => datas::all(),
            'networks' => network::all()
        ]);
    }


    private function direct(){
        return redirect(route('data.index'))->with([
            'success' =>true,
            'msg' => 'updated'
        ]);
    }

    private function validateRequest($request){
        $this->validate($request , [
            'network_id' => 'required',
            'amount' => 'required|string',
            'price' => 'required',
            'charges' =>'required',
            'check_balance' => 'required|string',
            'plan_code' =>'required',
            'description' => 'required'

        ]);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       // return $request->all();
        $this->validateRequest($request); 
        $data = new datas();
        $data->network_id = $request->network_id ;
        $data->amount = $request->amount ;
        $data->price = $request->price ;
        $data->charges = $request->charges ;
        $data->plan_code = $request->plan_code ;
        $data->check_balance = $request->check_balance;
        $data->description = $request->description;
        $data->save();
     return   $this->direct();

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = new datas();
        $response = new responses();
        return $response->general(true,'','',200,$data->where('id',$id)->get());
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validateRequest($request);
        $datas = new datas();
        $datas->where('id',$id)->update([
            'network_id' => $request->network_id,
            'amount' => $request->amount,
            'price' => $request->price,
            'charges' => $request->charges,
            'plan_code' => $request->plan_code,
            'description' => $request->description,
            'message' => ''


        ]);
      return  $this->direct();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

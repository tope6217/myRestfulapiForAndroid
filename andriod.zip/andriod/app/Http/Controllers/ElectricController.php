<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\electricities;
use App\responses;
use Config;
class ElectricController extends Controller
{

    public function __construct(){
        $this->middleware('verified',['except'=>['product']]);
    }

    public function product_confirmed($req){
        $electricity=new electricities();
        return   $electricity->where('id',$req->electric_id)->where('blocked',0)->select()->get();
    }

    public function type(){
        $electricity_type=new electricity_type();
        return $electricity_type->where('blocked',0)->select('id','name','type','charges','rate')->get();
    }

    public function type_confirmed($req){
        $electricity_type=new electricity_type();
        return   $electricity->where('id',$electric_id)->where('blocked',0)->select()->get();
    }
    public function product(){
        $electricity=new electricities();
        return $electricity->where('blocked',0)->select()->get();
    }

public function loader(){
    
}

    protected function request_id($length = 8) {
        return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
    }

    

    public function validateRonsponses(Request $request){
        $this->validate($request , [
          'electric_id' => 'required',
          'phonenumber' => 'required',
          'meterNo' => 'required',
          'type' => 'required',
        ]);
        $response = new responses();
        $data = $this->product_confirmed($request)[0];
        $responseArr = ['serviceCode' => $data->validateCode, 'amount'=>$request->amount, 'disco'=>$data->disco,'meterNo'=>$request->meterNo , 'type'=>$request->type ,'phonenumber'=>$request->phonenumber,'request_id'=>$this->request_id()];
        return $returnResponse = $response->validatedatas($responseArr);

      }

   // debit($id ,$details_amt,$product_amt);amt_check($Customer_amount, $product_amount); Customer_details($req)
   //username,desco,amount,meter-number,phone-number,request_id,type,
   public function buy(Request $request){
    $this->validate($request, [
        'phonenumber'=>'required',
        'type'=>'required',
        'meterNo'=>'required',
        'amount'=>'required',
        'electric_id' => 'required'
    ]);
    $responses = new responses();




    $product_details = $this->product_confirmed($request);

    if(count($product_details)<=0){
        return $responses->general(false , 'Not avaliable Try again later','',200,[]);
    }
    $product_details=$product_details[0];
    //return $product_details->rate;


    $request_id = $this->request_id();
    $price_to_pay = $request->amount + $product_details->charges;
    $x_charges = $product_details->charges;
    $isSufficient = $responses->isSufficient($price_to_pay);
    if(auth()->user()->type != 'admin'){
    if($isSufficient != true){
       return $responses->inSuficientResponse();
    }
    
}
            if($product_details->manually == 1){
                $responses->debit($price_to_pay);
                $responses->storeDebit('electricity',$request->type.' '.$product_details->disco,1,$request->amount,$x_charges,$price_to_pay,$request_id,false,'waiting',$request->amount,auth()->user()->amount,null,$request_id,$request->meterNo,$price_to_pay);
                return $responses->general(true,'Pending Transaction','Pending Transaction',200,[]);
            }
            $responseParameters = ([
                "serviceCode" => $product_details->serviceCode, 'phonenumber' => $request->phonenumber , 'meterNo' => $request->meterNo ,'amount' => $request->amount ,'type' => $request->type, 'disco' => $product_details->disco ,'request_id' => $request_id
            ]);
            //dd($responseParameters);
            $res = $responses->customer_api(config::get('app.electric'),$responseParameters);
           // return $res;
              if($res['status']=="200"){
                $responses->debit($price_to_pay);
                $x_charges = $price_to_pay-$res['amountCharged'];
                $responses->storeDebit('electricity',$request->type.' '.$product_details->disco,1,$request->amount,$x_charges,$price_to_pay,$res['TransRef'].'|'.$res['unit'],true,'done',$request->amount,auth()->user()->amount,null,$request_id,$request->meterNo,$price_to_pay);
                    return $responses->general(true,'','Transaction successful',200,[]);

              }elseif($res['status']==300){
                $note=  ["on"=>'ringo','notification'=>$res['message'],['message']=>"'".$res."'",'read'=>false];
                $this->notify($note);
                return $responses->general(false,'Try again later','',99,[]);
            }else{
                return $responses->general(false,'Try again later','',99,[]);

            }

        }

    
   
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\responses;
use App\User;
use Illuminate\Support\Facades\Validator;

class VerificationController extends Controller
{
    public function verify($user_id, Request $request) {
        $response = new responses();

        if (!$request->hasValidSignature()) {
            return $response->general(false,'Invalid/Expired url provided.','Invalid/Expired url provided.','401','');
        }
    
        $user = User::findOrFail($user_id);
    
        if (!$user->hasVerifiedEmail()) {
            $user->markEmailAsVerified();
        }
    
        return $response->general(true,'suceessfully verified.','suceessfully verified.','200','');
    }
    
    public function resend() {
        $response = new responses();

        if (auth()->user()->hasVerifiedEmail()) {
            return $response->general(true,'Email already verified.','Email already verified.','400','');
        }
    
        auth()->user()->sendEmailVerificationNotification();
            return $response->general(true,'Email verification link sent on your email id','Email verification link sent on your email id','200','');
    }
}

<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Validator;
use App\credit;
use App\User;
//use the Rave Facadeuse Rave;
use Rave;
class RaveController extends Controller{
/**
   * Initialize Rave payment process
   * @return void
   */public function initialize(){
    //This initializes payment and redirects to the payment gateway//The initialize method takes the parameter of the redirect URL
    Rave::initialize(route('callback'));
  }
/**
   * Obtain Rave callback information
   * @return void
   */public function verify(Request $req){
     // return $req->ref;
     $ref = $req->ref;
    // return $ref;
 $data = Rave::verifyTransaction($ref);
      if ($data->status == 'success') {
        // return $data->data->custemail;
         $cred['email' ]= $data->data->custemail;
         $cred['amount'] = $data->data->amountsettledforthistransaction;
         $cred['reference'] = $req->ref;
         
         //return $cred;
         //return $cred['a'];
         $credit=new credit();
            $credit_details= $credit->where('reference',$req->ref)->select()->get();
        if(count($credit_details)==0){
           $user =new User();
           $customer =$user->where('email',$cred['email'])->select()->get()[0];
           $cred['user_id'] = $customer->id;
           $credit->create($cred);
            $customer =$user->where('email',$cred['email'])->select()->get()[0];
            $customer_amt =$customer->amount;

          $total_amt=$customer_amt+$cred['amount'];
           $user->where('email',$cred['email'])->update([
              'amount'=>$total_amt
           ]);
           $this->responses('200');

        }else{
         $this->responses('130');

        }
}
else {
   $this->responses('200');
}
}


public function data(Request $req){
   $ref=$req->ref;
   $data=(Rave::verifyTransaction($ref));
   return $data;
}
}

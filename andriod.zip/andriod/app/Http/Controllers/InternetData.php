<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\internet;
use App\internet_data;
use App\internet_airtimes;
use App\responses;
use Config;
class InternetData extends Controller
{

  public function __contruct(){
    $this->middleware('verified',['except'=>['networks']]);
  }
  
  
      public function networks(){
          $internet = new internet();
        return  $internet->where('blocked',0)->with('datas')->get();
      }
  
      public function productData(){
          $internetData = new internet_data();
        $producta = internet::where('blocked' , false)->with('data')->get();
        return $producta;
      }

    public function product_data($request){
        $internetData = new internet_data();
      $producta = internet_data::where('id' , $request->data_id)->with('internet')->get();
      return $producta;
  }


    public function productAirtime(){
      return  internet_airtimes::where('blocked',false)->with('internet')->get();
    }


    protected function request_id($length = 8) {
        return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
    }

    public function validateRonsponses(Request $request){
      if(isset($request->recharge_id)){
        $request['data_id'] = $request->recharge_id;
      }
      $this->validate($request , [
        'data_id' => 'required',
        'account' => 'required'
      ]);
      $response = new responses();
     $data = $this->product_data($request)[0];
     $responseArr = (['serviceCode' => $data->internet->serviceCode,'account'=>$request->account]);
    // return ([$responseArr])->all();
    return $returnResponse = $response->validatedatas($responseArr);
    }

    public function data(Request $request)
    {

        $this->validate($request , [
            'data_id'=>'required|integer',
            'account'=>'required'
        ]);
        $response = new responses();
        $producta = $this->product_data($request);
       if(count($producta) <= 0){
    
        }  
         $product_data = $producta[0];
         $isSufficient = $response->isSufficient($product_data->price+$product_data->charges);  
         $charges = $product_data->charges;
         if(auth()->user()->type == 'member'){
         if($isSufficient != true){
           return $response->inSuficientResponse();
         }
        }

            $json_data = ([
                "type" => $product_data->internet->name,'serviceCode' => $product_data->internet->serviceCode,"code"=>$product_data->code,"account" => $request->account,'request_id' => $this->request_id(),'name' => $product_data->name, 'allowance' => $product_data->allowance , 'price' => $product_data->price,'validity' => $product_data->validity
            ]);
           //dd($json_data);
           // dd(Config::get('app.data'));
           //dd($response->ap()[1]->passwordorapi);
            $trans = $response->customer_api(Config::get('app.internet_data'),$json_data);
                $transaction= json_decode($trans,true);
                if($transaction['status'] == "200"){
                    $price_to_pay = $res['amountCharged'];
                    $d_price = $transaction['amountCharged'];
                    if($d_price >= $product_data->price){
                          $data->where('id',$product_data->id)->update(['price'=>$d_price,'message'=>'system_update']);
                          $product_data['price'] = $d_price ;
                      }
                      $price_to_pay = $product_data->price + $charges;
                      $x_charges = $price_to_pay-$res['amountCharged'];

                    $responses->debit($price_to_pay);
                    $responses->storeDebit($product_data->internet->name,$product_data->internet->name.' data',1,$product_data->name,$x_charges,$price_to_pay,$transaction['TransRef'],true,'done',$product_data->name,auth()->user()->amount,null,$request_id,$request->account,$price_to_pay);

                }elseif($transaction['status']=='402'){
                    return $response->general(false , 'transanction Unsuccessfull' , 'transanction successfull',99,[]);
                }else{
                     return  $response->general(false ,$transaction['message'] ,'', 202 ,[]);
                }
    }



    public function particular($airtime_id){
        return internet_airtimes::where('blocked','0')->where('id',$airtime_id)->with('internet')->get();
      }

    public function airtime(Request $request){
        $this->validate($request, [
            'amount'=>'required',
            'account'=>'required',
            'recharge_id'=>'required'
        ]);
        $response = new responses();
        $request_id = $this->request_id();
        $airtime=new internet_airtimes();
       $producta = $this->particular($request->recharge_id);
       if(count($producta) > 0){
        $product = $producta[0];
         $airtime_price = (($product->percentage) / 100) * $request->amount;
         //return $airtime_price;
         
         $isSufficient = $response-> isSufficient($airtime_price);
         //return $isSufficient;
  
         if(auth()->user()->type == 'member'){
         if($isSufficient != true ){
           return $response->inSuficientResponse();
         }
        }
         $producta = $producta[0];
             $json_data=([
                "amount"=>$request->amount,"account"=>$request->account,'serviceCode'=>$producta->serviceCode,'request_id'=>$request_id
                ]);
  //dd($json_data);
                //dd(Config::get('app.airtime'));
             $trans = $response->customer_api(config::get('app.internet_airtime') , $json_data);
            $transaction= json_decode($trans,true);
            // dd($transaction);
             if($transaction['status'] == "200"){
                $payment_from_ringo = $transaction['amountCharged'];
                 if($payment_from_ringo > $airtime_price){//software update
                   $a_percent= ($payment_from_ringo / $request->amount) * 100;
                     $airtime->where('id',$producta->id)->update(['percentage'=>$a_percent,'message'=>'system_update']);
                     $airtime_price = $a_percent*$request->amount;
                 }
                 $type = $transaction['type'];
                 $charges = $airtime_price - $payment_from_ringo;
                 $reference = $request_id;
                 $response->debit($airtime_price);//debit customer
            $response->storeDebit('Internet',$type,1,$request->amount,$charges,$airtime_price,$reference,true,'done',$request->amount,Auth()->user()->amount,$transaction,$reference,$request->account,$airtime_price);
            return $response->general(true,'','transaction successful',200,[]);
             }elseif($transaction['status']=='402'){
              return $response->general(false,'transaction unsuccessful','transaction successful',99,[]);//99
            }elseif($transaction['status']=='409'){
              return $response->general(false,'','transaction unsuccessful',111,[]);//111
            }else{
                 return $response->general(false,'','transaction unsuccessful',111,[]);//111
             }
                   
        }
    
    }
    }




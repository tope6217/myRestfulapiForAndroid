<?php

namespace App\Http\Controllers;

use App\internet_airtimes;
use Illuminate\Http\Request;
use App\internet;
use App\responses;
class InternetAirtimesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

     protected function database($id){
         return internet_airtimes::where('id',$id);
     }

     public function direct(){
         return redirect(route('internetairtime.index'));
     }

     protected function validateRequest($request){
         $this->validate($request , [
             'internet_id' => 'required',
             'percentage' => 'required',
             'blocked' =>  'required',
             'serviceCode' =>  'required'
         ]);
     }

    public function index()
    {
        return view('admin.internetairtime')->with([
            'internets' => internet::all(),
            'airtimes' => internet_airtimes::with('internet')->get()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validateRequest($request);
        $airtime = new internet_airtimes();
        $airtime->internet_id = $request->internet_id;
        $airtime->percentage = $request->percentage;
        $airtime->blocked = $request->blocked;
        $airtime->serviceCode = $request->serviceCode;
        $airtime->save();
        return $this->direct();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\internet_airtimes  $internet_airtimes
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $response = new responses();
        return $response->general(true,'successful','successful',200,$this->database($id)->get());
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\internet_airtimes  $internet_airtimes
     * @return \Illuminate\Http\Response
     */
    public function edit(internet_airtimes $internet_airtimes)
    {
        return 'll';
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\internet_airtimes  $internet_airtimes
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validateRequest($request);
        $this->database($id)->update([
            'internet_id' => $request->internet_id,
            'percentage' => $request->percentage,
            'blocked' => $request->blocked,
            'serviceCode' => $request->serviceCode,
            'message' => ''

        ]);
        return redirect(route('internetairtime.index'))->with([
            'success' => true,
            'msg' => 'updated'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\internet_airtimes  $internet_airtimes
     * @return \Illuminate\Http\Response
     */
    public function destroy(internet_airtimes $internet_airtimes)
    {
        //
    }
}

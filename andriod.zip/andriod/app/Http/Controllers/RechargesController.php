<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\network;
use App\datas;
use App\responses;
use App\airtime;
use Config;

class RechargesController extends Controller
{
    

  public function __construct(){
    $this->middleware('verified',['except'=>['network','FindAirtime']]);
  }

    public function networks(){
      $net = [];
      $networks = network::where('blocked',0)->get();
      foreach ($networks as $network) {
        $net[$network->id] = $network->name;
      }
      return ($net);
    }


    public function network(){
        $network=new network();
      return  $network->where('blocked',0)->with('datas')->get();
    }

    public function product_data($request){
      $data=new datas();
      $network=new network();
      $producta=$data->where('id',$request->data_id)->with('network')->select()->get();
      return $producta;
  }
  
  public function data(Request $request){
    $this->validate($request , [
        'data_id'=>'required|integer',
        //'amount'=>'required|integer',
        'number'=>'required'
    ]);
    $response = new responses();
    $producta = $this->product_data($request);
   if(count($producta)>0){

    }  
     $product_data = $producta[0];
     $isSufficient = $response->isSufficient($product_data->price);     
     if(auth()->user()->type == 'member'){
     if($isSufficient != true){
       return $response->inSuficientResponse();
     }
    }

     $network = $this->networks();
        $json_data = json_encode([
            "network"=>$product_data->network->name,"plan"=>$product_data->plan_code,"recipent"=>$request->number
        ]);
        //dd($json_data);
       // dd(Config::get('app.data'));
       //dd($response->ap()[1]->passwordorapi);
        $trans = $response->apii(Config::get('app.data'),($response->ap()[1]->passwordorapi),$json_data);
            $transaction= json_decode($trans,true);
            if($transaction['status'] == true){
                $d_price=$transaction['message']["details"]["amount"];
                if($d_price >= $product_data->price){
                      $data->where('id',$product_data->id)->where('amount',$request->amount)->update(['price'=>$d_price,'message'=>'system_update']);
                      $product_data->price = $d_price;
                  }
                  
            $response->debit($product_data->price);//debit customer
            $re_balance = Auth()->user()->amount;
            $request_id = $transaction["message"]["details"]["request_id"];
            $charges = $product_data->price - $transaction["message"]["details"]["total_charge"];
            $reference = $transaction["message"]["details"]["transaction_id"];
            $response->debit('data',$product_data->network->name,1,$product_data->amount,$charges,$product_data->price,$reference,true,'done',$product_data->amount,$re_balance,$trans,$request_id,$request->number,$product_data->price);
            return $response->general(true,'','transaction successfull',200,['category'=>'data','product_name'=>$product_data->network->name,$product_data->price,'status'=>true,'amount'=>$product_data->amount]);
            }elseif($transaction['status_code']=='402'){
                return $response->general(false , 'transanction Unsuccessfull' , 'transanction successfull',99,[]);
            }else{
                 return  $response->general(false ,$transaction['message']['description'] ,'', 202 ,[]);
            }
      }



      public function FindAirtime(){
         return airtime::where('blocked','0')->with('network')->get();
      }


      public function particular($airtime_id){
        return airtime::where('blocked','0')->where('id',$airtime_id)->with('network')->get();
      }
      public function airtime(Request $request){
        $this->validate($request, [
          'amount'=>'required',
          'number'=>'required',
          'airtime_id'=>'required'
      ]);
      $response = new responses();

      $airtime=new airtime();
     $producta = $this->particular($request->airtime_id);
     if(count($producta) > 0){
      $product = $producta[0];
      
       $airtime_price = (($product->percentage) / 100) * $request->amount;
       //return $airtime_price;
       
       $isSufficient = $response-> isSufficient($airtime_price);
       //return $isSufficient;

       if(auth()->user()->type == 'member'){
       if($isSufficient != true ){
         return $response->inSuficientResponse();
       }
      }
       $producta = $producta[0];
           $json_data=json_encode([
              "network"=>$producta->network->name,"amount"=>$request->amount,"recipent"=>$request->number
              ]);

              //dd(Config::get('app.airtime'));
           $trans = $response->apii(config::get('app.airtime'),($response->ap()[1]->passwordorapi),$json_data);
          $transaction= json_decode($trans,true);
          // dd($transaction);
           if($transaction['status'] == true){
               if($transaction["message"]["details"]["total_charge"] > $airtime_price){//software update
                 $a_percent= ($transaction["message"]["details"]["total_charge"]/$request->amount)*100;
                   $airtime->where('id',$producta->id)->update(['percentage'=>$a_percent,'message'=>'system_update']);
                   $airtime_price = $a_percent*$request->amount;
               }
               $charges = $airtime_price - $transaction["message"]["details"]["total_charge"];
               $reference = $transaction["message"]["details"]["transaction_id"];
               $response->debit($airtime_price);//debit customer
          $response->storeDebit('airtime',$producta->network->name,1,$request->amount,$charges,$airtime_price,$reference,true,'done',$request->amount,Auth()->user()->amount,$transaction,$reference,$request->number,$airtime_price);
          return $response->general(true,'','transaction successful',200,[]);
           }elseif($transaction['status_code']=='402'){
            return $response->general(false,'transaction unsuccessful','transaction successful',99,[]);//99
          }elseif($transaction['status_code']=='409'){
            return $response->general(false,'','transaction unsuccessful',111,[]);//111
          }else{
               return $response->general(false,$transaction['message']['description'],'transaction unsuccessful',111,[]);//111
           }
                 
      }
  
  }
      


}


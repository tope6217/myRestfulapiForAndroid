<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cable extends Model
{
    public function cables(){
        return $this->hasMany('App\cabletv');
    }
}

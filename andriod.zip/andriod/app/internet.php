<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class internet extends Model
{
    public function datas(){
        return $this->hasMany('App\internet_data');
    }
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class electricity_type extends Model
{
    
}
